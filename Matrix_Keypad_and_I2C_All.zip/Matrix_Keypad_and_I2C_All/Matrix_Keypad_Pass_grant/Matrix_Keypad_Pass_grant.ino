#include <Keypad.h>

const byte ROWS = 4;  // four rows
const byte COLS = 4;  // four columns
char keys[ROWS][COLS] = {
  { '1', '2', '3', 'A' },
  { '4', '5', '6', 'B' },
  { '7', '8', '9', 'C' },
  { '*', '0', '#', 'D' }
};

byte rowPins[ROWS] = { 5, 4, 3, 2 };
byte colPins[COLS] = { 9, 8, 7, 6 };

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

char password[5];  // 4 digits + null terminator
const char correctPassword[5] = "2513";
byte index = 0;
bool entering = false;
char key;
void setup() {
  Serial.begin(9600);
  pinMode(10, OUTPUT);
  Serial.println("Enter a 4-digit password:");

}

void loop() {
  key = 0;
  delay(100);
  while (key != '#') {
    key = keypad.getKey();
    if (key && (key != '#')) {
      Serial.print(key);
      password[index] = key;
      index++;
    }
    if(index > 4 && key != '#'){
      Serial.println("\nYou are entering more than 4 characters.");
      Serial.println("Enter a 4-digit password:");
      index = 0;
    }
    if (key == '#') {
      password[4] = '\0';  // terminate string
      Serial.println();

      if (strcmp(password, correctPassword) == 0) {
        Serial.println("Access Granted");
        digitalWrite(10, HIGH);  // example: turn on LED
        delay(1000);
        digitalWrite(10, LOW);
      } else {
        Serial.println("Access Denied");
        Serial.println("Enter a 4-digit password:");
      }

      index = 0;
    }
  }
}
